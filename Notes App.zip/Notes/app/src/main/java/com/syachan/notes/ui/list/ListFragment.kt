package com.syachan.notes.ui.list

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.syachan.notes.R
import com.syachan.notes.adapter.ListAdapter
import com.syachan.notes.databinding.FragmentListBinding
import com.syachan.notes.utils.hideKeyBoard
import com.syachan.notes.viewmodel.SharedViewModel
import com.syachan.notes.viewmodel.ToDoViewModel
import jp.wasabeef.recyclerview.animators.LandingAnimator


class ListFragment : Fragment() {

    private var _binding: FragmentListBinding? = null
    private val binding get() = _binding!!
    private val toDoViewModel: ToDoViewModel by viewModels()
    private val sharedViewModel: SharedViewModel by viewModels()

    private val adapter: ListAdapter by lazy { ListAdapter() }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = DataBindingUtil.inflate(inflater, R.layout.fragment_list, container, false)
        binding.lifecycleOwner = this
        binding.sharedViewModel = sharedViewModel
        toDoViewModel.getAllData.observe(viewLifecycleOwner, Observer { data ->
            sharedViewModel.checkDatabseEmpty(data)
            adapter.setData(data)
        })
        setupRecyclerView()
        hideKeyBoard(requireActivity())
        return binding.root
    }

    private fun setupRecyclerView() {
        val rv = binding.recyclerView
        rv.adapter = adapter
        rv.layoutManager = StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL)
        rv.itemAnimator = LandingAnimator().apply {
            addDuration = 300
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}