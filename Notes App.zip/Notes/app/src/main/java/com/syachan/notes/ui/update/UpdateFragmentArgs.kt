package com.syachan.notes.ui.update

class UpdateFragmentArgs {
}