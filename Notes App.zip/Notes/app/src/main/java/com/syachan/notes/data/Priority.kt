package com.syachan.notes.data

enum class Priority {
    HIGH,
    MEDIUM,
    LOW
}